//
//  MedLogger.h
//  MedLogger
//
//  Created by ADMIN on 14/12/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for MedLogger.
FOUNDATION_EXPORT double MedLoggerVersionNumber;

//! Project version string for MedLogger.
FOUNDATION_EXPORT const unsigned char MedLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MedLogger/PublicHeader.h>


